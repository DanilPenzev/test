/**
* Creates an ENUM of type of data recieved from server.
* @enum
* @desc Enum representing different types of data recieved from server
*/
var Context = ( Context || {} );

Context.DataRecievedType = {
    SetPathFromTagBrowser: 10000,
    SetContexts: 10001,
    SetContextValues: 10002,
    LanguageChange: 10003
};
/**
* Creates an ENUM of different types of events
* @enum
* @desc Enum representing different types of events
*/
Context.DataEvents = {
    TagBrowser: 500,
    Contexts: 501,
    ContextValues: 502,
    SelectContext: 503,
    LanguageId:504
};
/**
* Creates an ENUM of different types of languages
* @enum
* @desc Enum representing different types of languages
*/
Context.Language = {
    English: 1033
};
